import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './component/header/header.component';
import { CartComponent } from './component/cart/cart.component';
import { ProductComponent } from './component/product/product.component';
import { HttpClientModule} from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { ProductViewComponent } from './component/product-view/product-view.component';
import { FilterPipe } from './shared/filter.pipe';
import { FormsModule, ReactiveFormsModule} from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DealsComponent } from './component/deals/deals.component';
import { DealsformComponent } from './component/dealsform/dealsform.component';
import { SearcherrorComponent } from './component/searcherror/searcherror.component';
// import { MatIconModule } from '@angular/material';
// import {MatButtonModule, MatCheckboxModule} from '@angular/material';
@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    CartComponent,
    ProductComponent,
    ProductViewComponent,
    FilterPipe,
    DealsComponent,
    DealsformComponent,
    SearcherrorComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    RouterModule,
	FormsModule,
	ReactiveFormsModule,
	BrowserAnimationsModule,
  
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { 
  
}

