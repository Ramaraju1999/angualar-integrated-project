import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CartService {

  public search = new BehaviorSubject<string>("");
  public examplelist= new BehaviorSubject<any>([""]);
  filteredlist:any=[];
  getfilteredlist(){
    return this.examplelist.next(this.filteredlist);
  }
  setfilteredlist(data: any): void{
   
   this.filteredlist.push(...data);
  }
  constructor() { }
}
