import { Injectable } from '@angular/core';

import {HttpClient, HttpHeaders} from '@angular/common/http'
import { HttpErrorResponse } from '@angular/common/http';
import { User } from '../user';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})


export class RegistrationserviceService {

  constructor(private _http:HttpClient) { }

  public addproductremote(user: User):Observable<any>{
    return this._http.post<any>('http://localhost:4500/products/addproduct',user);      
  }

}
