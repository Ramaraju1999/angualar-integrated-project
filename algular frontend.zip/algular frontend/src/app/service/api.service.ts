import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import {tap,map,catchError} from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class ApiService {


  constructor( private http: HttpClient) { }
  getproduct(){
    return this.http.get<any>("http://localhost:4500/products/getall")
    .pipe(map((res:any)=>{
      return res;
    }))
  }

  getMatchedproducts(searchTerm:any){
	return this.http.get<any>("http://localhost:4500/products/getmatched/"+searchTerm)
    .pipe(map((res:any)=>{
      console.log(res);
      
      return res; 
      
    }))
  }


  getOne(id : any)
  {
    return this.http.get<any>("http://localhost:4500/products/getbyid/"+id)
    .pipe(map((res:any)=>{
      return res;
    }))
  }
  // addToCart(productId:number):Observable<any> {
  //   const options = new HttpHeaders({'contentType':'application/json','Accept': 'application/json'})
  //   return this.http.put("http://localhost:5555/cart/add/"+productId+"?user="+3,{}).pipe(
  //     tap(data=>console.log(data)),  
  //     catchError(this.handleError)
  //   )
  // }

  private handleError(err: HttpErrorResponse): Observable<any> {
    console.log("Gone");
    let errMsg = '';
    if (err.error instanceof Error) {
      // A client-side or network error occurred. Handle it accordingly.
      console.log('An error occurred:', err.error.message);
      errMsg = err.error.message;
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      console.log(err);
      console.log(`Backend returned code ${err.status}`);
      errMsg = err.error.status;
    }
    return throwError(errMsg);
  }
}
