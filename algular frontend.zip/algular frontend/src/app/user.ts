export class User {
    productName!: string;
    productDescription! : string;
    productPrice! : string;
    productDiscount!:string;
    productImage!:string;
    productRating!:string;
    constructor(){}
}
