import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SearcherrorComponent } from './searcherror.component';

describe('SearcherrorComponent', () => {
  let component: SearcherrorComponent;
  let fixture: ComponentFixture<SearcherrorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SearcherrorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SearcherrorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
