import { Component, OnInit ,Input } from '@angular/core';

@Component({
  selector: 'app-searcherror',
  templateUrl: './searcherror.component.html',
  styleUrls: ['./searcherror.component.css']
})
export class SearcherrorComponent implements OnInit {

  constructor() { }
  @Input() viewList:any;
  ngOnInit(): void {
  }

}
