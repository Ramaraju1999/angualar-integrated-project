import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { RegistrationserviceService } from 'src/app/service/registrationservice.service';
import { User } from 'src/app/user';
@Component({
  selector: 'app-dealsform',
  templateUrl: './dealsform.component.html',
  styleUrls: ['./dealsform.component.css']
})
export class DealsformComponent implements OnInit {

  user =new User;
  msg='';

  constructor(private _service: RegistrationserviceService, private _router:Router, private formBuilder: FormBuilder) { }

  ngOnInit(): void {
  }
  addproduct() {
    console.log(this.user);
    this._service.addproductremote(this.user).subscribe(
      data=> {
        console.log("response revceived");
        this.msg="product added success";
        console.log(data);
      },
      // error=>{
      //     console.log(error);
      // }
      
    );
  }

}

