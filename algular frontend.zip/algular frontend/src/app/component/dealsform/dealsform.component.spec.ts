import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DealsformComponent } from './dealsform.component';

describe('DealsformComponent', () => {
  let component: DealsformComponent;
  let fixture: ComponentFixture<DealsformComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DealsformComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DealsformComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
