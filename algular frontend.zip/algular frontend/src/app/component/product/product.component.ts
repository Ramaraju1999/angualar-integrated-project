import { analyzeAndValidateNgModules } from '@angular/compiler';
import { Component, OnInit ,Input} from '@angular/core';
import { Router } from '@angular/router';
import { ApiService } from 'src/app/service/api.service';
import { CartService } from 'src/app/service/cart.service';
@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
  showerror!: boolean;
  public productList : any ;
  searchKey:string="";
  starCount =5;
  ratingArr: boolean[] = [];
  ratingNonArr: boolean[] = [];
  public ratings: any;
  @Input() viewList:any;
  name:any;

  iserror!:boolean;
  // this.name=this.viewList.productName;
  
  isEmpty!: boolean;
  searchlength:any;
  constructor(private api : ApiService, private cartService : CartService ,private router:Router  ) { }

  ngOnInit(): void {
    this.api.getproduct().subscribe(res=>{
      this.productList=res;
      this.ratings=this.productList.rating;
      console.log(res.length);
      
    })


    this.api.getMatchedproducts(this.searchKey).subscribe(les=>{
      this.viewList=les;
      // this.ratings=this.productList.rating;
      console.log(this.viewList);
      
    })

    
    console.log(this.isEmpty);
    this.cartService.search.subscribe(val=>{
      this.searchKey =val;
      console.log(this.searchKey);
      this.searchlength=this.searchKey.length;
      if(this.searchlength>0 && this.viewList.length>0 ){
        this.isEmpty=true;
        console.log("search length is zero");
      }
      
      if(this.searchlength==0){
        this.isEmpty=false;
      }

      if(this.viewList.length==0 && this.searchlength>0)
      {
          this.iserror=true;
      }
      else{
        this.iserror=false;
      }
    
    })

  }

  /*addToCart(productId:Number) {
    console.log("added")
      this.api.addToCart(productId).subscribe(res=>{
        console.log(res);
      })
  }
*/
  change(id:any){
    console.log("Clicked")
    this.router.navigate(['/product-view',id]);
  }

}
