import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApiService } from 'src/app/service/api.service';
import { CartService } from 'src/app/service/cart.service';
@Component({
  selector: 'app-deals',
  templateUrl: './deals.component.html',
  styleUrls: ['./deals.component.css']
})
export class DealsComponent implements OnInit {

  public productList : any ;
  constructor(private api : ApiService, private cartService : CartService ,private router:Router ) { }

  
  ngOnInit(): void {
    this.api.getproduct()
    .subscribe(res=>{
      this.productList=res;
      console.log(res)
    })

  } 
  change(id:any){
    console.log("Clicked")
    this.router.navigate(['/product-view',id]);
  }
  
}
