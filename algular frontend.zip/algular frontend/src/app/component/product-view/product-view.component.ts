import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
// import { Console } from 'console';
import { ApiService } from 'src/app/service/api.service';

// import{MatSnackBar} from '@angular/material/snack-bar';


@Component({
  selector: 'app-product-view',
  templateUrl: './product-view.component.html',
  styleUrls: ['./product-view.component.css']
})

export class ProductViewComponent implements OnInit {

  public productidList : any ;
  id: any;
  starCount =5;
  ratingArr: boolean[] = [];
  ratingNonArr: boolean[] = [];
  public productName: any;
  public description: any;
  public price: any;
  public discount: any;
  public imageURL: any;
  // public quantity: any;
  public seller: any;
  public rating: any;
  public totalprice:any;

  
  constructor(private api : ApiService , private route : ActivatedRoute, ) { 
    
  }
  

  ngOnInit(): void {
   
    this.id=this.route.snapshot.params['id'];
    this.getOne();
  }
  
  
  getOne()
  {
    this.api.getOne(this.id).subscribe(data=>{
      console.log(data);
      this.productName=data.productName;
      this.description=data.description;
      this.price=data.price;
      this.discount=data.discount;
      this.imageURL=data.imageURL;
      // this.quantity=data.quantity;
      this.seller=data.seller;
      this.rating=data.rating;
      this.ratingArr = Array(this.rating).fill(false);
      this.starCount= this.starCount-this.rating;
      this.totalprice =this.price-this.discount;
      this.ratingNonArr = Array(this.starCount).fill(false);
    })
  }
}
