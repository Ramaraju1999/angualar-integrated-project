import { Component,OnInit } from '@angular/core';
import { ApiService } from 'src/app/service/api.service';
import { CartService } from './service/cart.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'ekart';
  public searchTerm : string ='';
  constructor(private api:ApiService , private cartService :CartService){}
  // constructor(private cartService : CartService) { }
  ngOnInit():void{
    
  }
  filteredlist:any =[];
  listlength:any;
  isEmpty!:boolean;
  noproduct: any;
  nosearch: any;
  viewList: any;
  search(event:any) {
	this.searchTerm = (event.target as HTMLInputElement).value;
	if(this.searchTerm.length>0){
	this.api.getMatchedproducts(this.searchTerm)
    .subscribe(res=>{
      this.viewList=res;
      console.log(res)
      // this.listlength=res;
      
    })
	}
	// console.log(this.searchTerm);
  this.nosearch =this.searchTerm.length;
  
  this.cartService.search.next(this.searchTerm);
  if(this.nosearch==0 )
  {
    this.isEmpty=false;
  }

  

  }
 
// .cartService.getfilteredlist(this.viewList){
//     this.filteredlist.push(...this.viewList);
//   }
//   this.cartService.setfilteredlist(this.viewList): any{
   
//     this.filteredlist.push(...this.viewList);
//    }
}
