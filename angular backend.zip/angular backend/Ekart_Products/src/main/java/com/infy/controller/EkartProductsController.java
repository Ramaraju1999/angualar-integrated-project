package com.infy.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infy.DTO.EkartProductsCertainDTO;
import com.infy.DTO.EkartProductsDTO;
import com.infy.service.EkartProductsService;

@CrossOrigin
@RestController
@RequestMapping("/products")
public class EkartProductsController {
	
	@Autowired
	EkartProductsService productService;
	
	@PostMapping(value="/create")
	public String CreateDataBaseTables() {
		productService.CreateDataBaseTables();
		return "Vachindra baby";
		
	}
	
	@GetMapping(value="/getall")
	public List<EkartProductsDTO> getAllProducts(){
		return productService.getAllProducts();
	}
	
	@GetMapping(value="/getmatched/{productName}")
	public List<EkartProductsDTO> getMatchedProducts(@PathVariable("productName") String productName){
		return productService.getMatchedProducts(productName);
	}
	
	@PostMapping(value="/getbyname/{name}")
	public List<EkartProductsDTO> getProductByName(@PathVariable("name") String name) {
//		return name;
		return productService.getProductByName(name);
	}
	
	@GetMapping(value="/getbyid/{id}")
	public EkartProductsDTO getProductById(@PathVariable("id") String id) {
//		return name;
		System.out.println("reached controller product");
		return productService.getProductById(Integer.parseInt(id));
	}
	
}
