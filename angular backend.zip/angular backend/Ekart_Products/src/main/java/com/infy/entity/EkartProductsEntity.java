package com.infy.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity(name="ekart_products")
public class EkartProductsEntity {
	@Id
	@Column(name = "product_id")
	private int productId;
	@Column(name = "product_name")
	private String productName;
	private String description;
	private long price;
	private int rating;
	private String category;
	@Column(name = "image_url")
	private String imageURL;
	private String seller;
	private long discount;
	private int quantity;
	public EkartProductsEntity() {
		super();
	}
	
	public EkartProductsEntity(int productId,String productName, String description, long price, int rating,
			String category, String imageURL, String seller, long discount, int quantity) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.description = description;
		this.price = price;
		this.rating = rating;
		this.category = category;
		this.imageURL = imageURL;
		this.seller = seller;
		this.discount = discount;
		this.quantity = quantity;
	}

	public long getDiscount() {
		return discount;
	}

	public void setDiscount(long discount) {
		this.discount = discount;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getDescription() {
		return this.description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public long getPrice() {
		return price;
	}
	public void setPrice(long price) {
		this.price = price;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getImageURL() {
		return imageURL;
	}
	public void setImageURL(String imageURL) {
		this.imageURL = imageURL;
	}
	public String getSeller() {
		return seller;
	}
	public void setSeller(String seller) {
		this.seller = seller;
	}
	@Override
	public String toString() {
		return "ekartProductsEntity [productId=" + productId + ", productName=" + productName + ", description="
				+ description + ", price=" + price + ", rating=" + rating + ", category=" + category + ", imageURL="
				+ imageURL + ", seller=" + seller + ", discount=" + discount + ", quantity=" + quantity + "]";
	}
	
	
}
