package com.infy.service;

import java.util.List;

import com.infy.DTO.EkartProductsCertainDTO;
import com.infy.DTO.EkartProductsDTO;

public interface EkartProductsService {
	public List<EkartProductsDTO> getAllProducts();
	
	public List<EkartProductsDTO> getMatchedProducts(String name);
	
	public List<EkartProductsDTO> getProductByName(String productName);
	
	
	public void CreateDataBaseTables();

	public EkartProductsDTO getProductById(int id);
}
