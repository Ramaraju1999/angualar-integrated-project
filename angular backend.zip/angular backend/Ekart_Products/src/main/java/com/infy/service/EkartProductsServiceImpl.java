package com.infy.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.DTO.EkartProductsCertainDTO;
import com.infy.DTO.EkartProductsDTO;
import com.infy.entity.EkartProductsEntity;
import com.infy.repo.EkartProductsRepository;
@Service("EkartProductsService")
public class EkartProductsServiceImpl implements EkartProductsService {
	
	@Autowired
	EkartProductsRepository productsRepo;
	
	public void CreateDataBaseTables() {
		int count=0;
		for(int i=0;i<5;i++) {
			for(int j=0;j<5;j++) {
				EkartProductsEntity customerEntity = new EkartProductsEntity(count++,"Mobile"+(i+j),"Description"+(i+j),100+j,j-i,"Category"+i,"../../assets/images/"+(i+j)+".jpg","seller"+(i+j),50-j,j*i);
				System.out.println(customerEntity);
				productsRepo.saveAndFlush(customerEntity);
			}
		}
		
	}
	
	public List<EkartProductsDTO> getAllProducts() {
		Iterable<EkartProductsEntity> products = productsRepo.findAll();
		List<EkartProductsDTO> productDTOs = new ArrayList<>();
		products.forEach(product-> {
		EkartProductsDTO productDTO = EkartProductsDTO.prepareDTO(product);
		productDTOs.add(productDTO);
		});
		return productDTOs;		
	}
	
	public List<EkartProductsDTO> getMatchedProducts(String name) {
		Iterable<EkartProductsEntity> products = productsRepo.findByProductNameContainingIgnoreCase(name);
		List<EkartProductsDTO> productDTOs = new ArrayList<>();
		products.forEach(product-> {
		EkartProductsDTO productDTO =EkartProductsDTO.prepareDTO(product);
		productDTOs.add(productDTO);
		});
		return productDTOs;		
	}
	
	public List<EkartProductsDTO> getProductByName(String productName) {
		List<EkartProductsDTO> productsDTOs = new ArrayList<>();
		for(EkartProductsEntity productEntity : productsRepo.findByProductName(productName)) {
			 productsDTOs.add(EkartProductsDTO.prepareDTO(productEntity));	 
		}
		return productsDTOs;
	}
	
	public EkartProductsDTO getProductById(int id) {
		Optional<EkartProductsEntity> productEntity = productsRepo.findById(id);
		if(productEntity.isPresent())
		return EkartProductsDTO.prepareDTO((productEntity.get()));
		return new EkartProductsDTO();
	}
}
