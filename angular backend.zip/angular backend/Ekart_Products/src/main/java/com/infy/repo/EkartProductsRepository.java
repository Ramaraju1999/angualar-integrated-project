package com.infy.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.infy.entity.EkartProductsEntity;


public interface EkartProductsRepository extends JpaRepository<EkartProductsEntity,Integer>{
	public List<EkartProductsEntity> findByProductName(String productName);
	public List<EkartProductsEntity> findByProductNameContainingIgnoreCase(String productName);
}
