package com.infy.DTO;

public class EkartProductsCertainDTO {
	
	private int productId;
	private String productName;
	private String description;
	private long price;
	private int rating;
	private String imageURL;
	
	public EkartProductsCertainDTO() {
		super();
	}

	public EkartProductsCertainDTO(int productId, String productName, String description, long price, int rating,
			String imageURL) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.description = description;
		this.price = price;
		this.rating = rating;
		this.imageURL = imageURL;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public long getPrice() {
		return price;
	}

	public void setPrice(long price) {
		this.price = price;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public String getImageURL() {
		return imageURL;
	}

	public void setImageURL(String imageURL) {
		this.imageURL = imageURL;
	}

	@Override
	public String toString() {
		return "EkartProductsCertainDTO [productId=" + productId + ", productName=" + productName + ", description="
				+ description + ", price=" + price + ", rating=" + rating + ", imageURL=" + imageURL + "]";
	}
	
	
}
