package com.infy.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.infy.entity.EkartCartEntity;


public interface EkartCartRepository extends JpaRepository<EkartCartEntity,Integer>{
	public Optional<EkartCartEntity> findByProductIdAndUserId(int pinCode, int userId);
}
