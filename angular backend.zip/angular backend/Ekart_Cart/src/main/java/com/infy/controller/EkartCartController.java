package com.infy.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infy.DTO.EkartProductsDTO;
import com.infy.service.CartHystrixService;
import com.infy.service.EkartCartService;


@CrossOrigin
@RestController
@RequestMapping("/cart")
public class EkartCartController {

	@Autowired
	EkartCartService cartService;
	
	@Autowired
	CartHystrixService hystrixService;
	
	@PutMapping(value="/add/{productId}")
	public ResponseEntity<String> addProductToCart(@PathVariable("productId") int productId,@RequestParam("user") int userId) {
		System.out.println("Reached control");
		EkartProductsDTO product = hystrixService.getProductDetails(productId);
		ResponseEntity<String> output = cartService.addorUpdateProductToCart(product,userId);
		System.out.println("Hello -->"+output+" "+productId+ " "+userId);
		return output;
	}
	

}
