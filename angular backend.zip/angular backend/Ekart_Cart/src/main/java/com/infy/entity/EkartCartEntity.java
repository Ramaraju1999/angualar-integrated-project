package com.infy.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity(name="ekart_cart")
public class EkartCartEntity {
	@Id
	@Column(name="cart_id")
	private int cartId;
	@Column(name = "product_id")
	private int productId;
	@Column(name="user_id")
	private int userId;
	@Column(name = "product_name")
	private String productName;
	private String description;
	private long price;
	private String category;
	@Column(name = "image_url")
	private String imageURL;
	private long discount;
	private int quantity;
	public EkartCartEntity() {
		super();
	}
	public EkartCartEntity(int cartId, int productId, int userId, String productName, String description, long price,
			String category, String imageURL, long discount, int quantity) {
		super();
		this.cartId = cartId;
		this.productId = productId;
		this.userId = userId;
		this.productName = productName;
		this.description = description;
		this.price = price;
		this.category = category;
		this.imageURL = imageURL;
		this.discount = discount;
		this.quantity = quantity;
	}
	public int getCartId() {
		return cartId;
	}
	public void setCartId(int cartId) {
		this.cartId = cartId;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public long getPrice() {
		return price;
	}
	public void setPrice(long price) {
		this.price = price;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getImageURL() {
		return imageURL;
	}
	public void setImageURL(String imageURL) {
		this.imageURL = imageURL;
	}
	public long getDiscount() {
		return discount;
	}
	public void setDiscount(long discount) {
		this.discount = discount;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "EkartCartEntity [cartId=" + cartId + ", productId=" + productId + ", userId=" + userId
				+ ", productName=" + productName + ", description=" + description + ", price=" + price + ", category="
				+ category + ", imageURL=" + imageURL + ", discount=" + discount + ", quantity=" + quantity + "]";
	}
	
	
}
