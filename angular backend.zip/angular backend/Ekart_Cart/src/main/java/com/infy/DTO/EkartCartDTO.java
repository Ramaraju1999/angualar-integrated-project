package com.infy.DTO;

import com.infy.entity.EkartCartEntity;

public class EkartCartDTO {
	private int cardId;
	private int productId;
	private int userId;
	private String productName;
	private String description;
	private long price;
	private String category;
	private String imageURL;
	private long discount;
	private int quantity;
	
	public EkartCartDTO() {
		super();
	}

	public EkartCartDTO(int cardId, int productId, int userId, String productName, String description, long price,
			String category, String imageURL, long discount, int quantity) {
		super();
		this.cardId = cardId;
		this.productId = productId;
		this.userId = userId;
		this.productName = productName;
		this.description = description;
		this.price = price;
		this.category = category;
		this.imageURL = imageURL;
		this.discount = discount;
		this.quantity = quantity;
	}

	public int getCardId() {
		return cardId;
	}

	public void setCardId(int cardId) {
		this.cardId = cardId;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public long getPrice() {
		return price;
	}

	public void setPrice(long price) {
		this.price = price;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getImageURL() {
		return imageURL;
	}

	public void setImageURL(String imageURL) {
		this.imageURL = imageURL;
	}

	public long getDiscount() {
		return discount;
	}

	public void setDiscount(long discount) {
		this.discount = discount;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		return "EkartCartDTO [cardId=" + cardId + ", productId=" + productId + ", userId=" + userId + ", productName="
				+ productName + ", description=" + description + ", price=" + price + ", category=" + category
				+ ", imageURL=" + imageURL + ", discount=" + discount + ", quantity=" + quantity + "]";
	}
	
	
}
