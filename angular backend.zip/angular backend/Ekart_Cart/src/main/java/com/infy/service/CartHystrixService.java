package com.infy.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.infy.DTO.EkartProductsDTO;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service
public class CartHystrixService {
	@Autowired
	RestTemplate restTemplate;
	
	@HystrixCommand(fallbackMethod="getProductFallBack")
	public EkartProductsDTO getProductDetails(int productId) {
		System.out.println("Reached Hystrix");
		return restTemplate.getForObject("http://EkartProductsMS"+"/products/getbyid/"+productId,EkartProductsDTO.class);
	}
	public EkartProductsDTO getProductFallBack(int productId) {
		return new EkartProductsDTO();
	}

}
