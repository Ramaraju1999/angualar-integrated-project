package com.infy.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.ResponseBody;

import com.infy.DTO.EkartProductsDTO;
import com.infy.entity.EkartCartEntity;
import com.infy.repo.EkartCartRepository;

import io.micrometer.core.ipc.http.HttpSender.Response;
@Service("EkartProductsService")
public class EkartCartServiceImpl implements EkartCartService {
	
	@Autowired
	EkartCartRepository cartRepo;

	
	public ResponseEntity<String> addorUpdateProductToCart(EkartProductsDTO product,int userId) {
		Optional<EkartCartEntity> cartProductOpt = cartRepo.findByProductIdAndUserId(product.getProductId(), userId);
		if(cartProductOpt.isPresent()) {
			EkartCartEntity cartProduct = cartProductOpt.get();
			cartProduct.setQuantity(cartProduct.getQuantity()+1);
			cartProduct.setPrice(cartProduct.getPrice()+product.getPrice());
			cartProduct.setDiscount(cartProduct.getDiscount()+product.getDiscount());
			cartRepo.saveAndFlush(cartProduct);
			System.out.println("Updated the Cart");
			return ResponseEntity.ok("Updated the Cart");
		}
		EkartCartEntity cartEntity = new EkartCartEntity((int)(cartRepo.count())+1, product.getProductId(), userId, product.getProductName(), product.getDescription(), product.getPrice(), product.getCategory(), product.getImageURL(),product.getDiscount(),1);	
		cartRepo.saveAndFlush(cartEntity);
		System.out.println("Created the cart");
		return ResponseEntity.ok("Created the Cart");
	}

	

}
