package com.infy.service;

import org.springframework.http.ResponseEntity;

import com.infy.DTO.EkartProductsDTO;

public interface EkartCartService {
	public ResponseEntity<String> addorUpdateProductToCart(EkartProductsDTO product,int userId);

}
